# Trident-Shards-Resources

This is the repository for the resource pack for Trident Shards! Please go [here](https://github.com/DBTDerpbox/Trident-Shards)
